#!/system/bin/sh
if [ -d /data/adb/modules/apple ] || [ -d /data/adb/modules_update/apple ] || [ -d /data/adb/modules/tkdroid_consumer ] || [ -d /data/adb/modules_update/tkdroid_consumer ]; then
  ui_print "! The full TkDroid or TkDroid Consumer is installed. The demo is not needed and would replace its commands."
  abort "! TkDroid Demo was not installed"
fi
ui_print "- TkDroid Demo v3.1.4 Patch 4: tkinter -> APK (limited edition)"
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/apkapple.sh" 0 0 0755
set_perm "$MODPATH/install_termux.sh" 0 0 0755
. "$MODPATH/migrate.sh"
tkdroid_migrate_all                       # ApkApple folders and data -> TkDroid
mkdir -p /data/adb/tkdroid
sh "$MODPATH/install_termux.sh" "$MODPATH"
[ -x /data/data/com.termux/files/usr/bin/tkdroid ] && ui_print "- Termux command installed: tkdroid"
ui_print "- Usage (normal Termux user, NOT tsu):  tkdroid run app.py"
ui_print "- First run: tkdroid doctor, then tkdroid demo"
ui_print "- Limits: tkdroid help. Consumer version: open an app built with TkDroid > About TkDroid > Request the consumer version"
ui_print "- No reboot needed"
