#!/system/bin/sh
# Re-sync the Termux copy at boot (e.g. after Termux was reinstalled)
MODDIR=/data/adb/modules/tkdroid_demo
[ -x /data/data/com.termux/files/usr/bin/tkdroid ] || sh "$MODDIR/install_termux.sh" "$MODDIR"
